
Evil Bunny Trojan
=================

A simple trojan keylogger written in Python, disguised as an animated ASCII
bunny (made for pedagogical purposes)

It uses [this small keylogging python lib](https://github.com/amoffat/pykeylogger)

Usage
-----

- In a first console, type `python evilBunnyServer.py`
- In another console, type `python evilBunnyTrojan.py`
- Get hyptnotized by the dancing bunny
- Press keys anywhere in your OS and watch the server getting logs of which
  keys you pressed
